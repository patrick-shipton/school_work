ReadMe.txt for COMP 2406 Assignment 3

Develper: Patrick Shipton 101046238
Develped on: Windows 7 and Chrome
Start Date: 20/11/2017
Last edit: 21/11/2017


To run:
	1. Go to the directpry containing the package.json and the food2fork_server.js
	2. Run 'npm install'
	3. Run 'npm start'
	
Note: Use Ctrl+C and then type 'y' to close server

How to use app:
	1. go to 'http://localhost:3000'
	2. type ingredient(s) into input box
	3. click the 'Get Recipes' button
	
	Or
	
	1. go to 'http://localhost:3000/recipes?ingredient=${ingredient}'
		ex: 'http://localhost:3000/recipes?ingredient=ginger,cocoa'
	
Note: The images of the recipes are links to the food2fork website