Notes:
The sqlite3.exe is included here so you can run the sqlite3 database from a cmd console.
It is not needed for the node.js application.

Documentation on how to use the CLI command line interface to sqlite is here:

http://www.sqlite.org/cli.html

For sql syntax see here:
http://www.sqlite.org/lang.html